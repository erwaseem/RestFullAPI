const mongoose=require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/studentAPI')
.then(()=>console.log('Database connected succesffulyy'))
.catch((err)=>console.log(err));



