const express=require('express');
 require("./db/conn");
 const Student=require("./model/student");
const app=express();

const port=process.env.PORT|| 2000;
app.use(express.json())
app.get("/",(req,res)=>{
    res.send("hello ddddddddd");
})
app.post('/students',(req,res)=>{
    console.log(req.body)
   const user=new Student(req.body)
   user.save().then(() => {
       res.status(201);
       res.send(user);
   }).catch((err) => {
       res.status(400);
       res.send(err);
   });
})
app.listen(port,()=>{
    console.log('connected is etup at ${port}');

})