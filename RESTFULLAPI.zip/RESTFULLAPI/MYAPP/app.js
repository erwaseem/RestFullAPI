   const mongoose=require('mongoose');
   var validator = require('validator');
    mongoose.connect(' mongodb://127.0.0.1:27017/studentDb')
    .then(()=>console.log('Database connected succesffulyy'))
    .catch((err)=>console.log(err));

//  Step 1 scema
const playlistScema=new mongoose.Schema({
   name:{ 
      type:String,
       required:true
      },
   ctype:String,
   videos:Number,
   author:String,
   active:Boolean,
   date:
    {type:Date,default:Date.now},
    email:{
           type:String,
           required:true,
           unique:true,
           validate(value){
              if(!validator.isEmail(value))
              {
                 throw new  Error("invalid");
              }
           }

    }
})
//  step 2 wrrping with model 
    const Playlist=new mongoose.model("Platlist",playlistScema);
      //create or insert

    
     const createDocument=async()=>{
      try{
         const reactPlaylist=new Playlist({
            name:'MEAN STACK ',
            ctype:'Full stack',
            videos:80,
            author:'Waseem ahmad',
            email:'waseem@gmail.com',
            active:true
         })
           const result=await reactPlaylist.save();
           console.log(result);
      }
      catch(err)
      {
            console.log(err);
      }
     }

     //  for reading data 
       const getDocument=async()=>{
          const result =await Playlist.find();
          console.log(result);
       }
     createDocument();
      // getDocument();

      //  for upadating data
        const updateDocument =async(_id)=>{
           try{
            const result=await Playlist.updateOne({_id},{
               $set:{
                  name:'JavaScript'
               }
          });
          console.log(result);
           }
           catch(err)
           {
                console.log(err);
           }
        }
      //   updateDocument('615541e2303f16b63a66c7ff');
        const deleteDocument =async(_id)=>{
            try{
               const result=await Playlist.deleteOne({_id});
               console.log(result);
            }
            catch(err)
            {
               console.log(err);
            }
        }
         //  deleteDocument('615543a0592f890e59703896');